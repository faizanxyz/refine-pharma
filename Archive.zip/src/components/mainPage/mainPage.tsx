import MiniDrawer from "../navbar/navbar"


function MainPage(){
    return(
        <>
       <MiniDrawer/>
        </>
    )
}

export default MainPage